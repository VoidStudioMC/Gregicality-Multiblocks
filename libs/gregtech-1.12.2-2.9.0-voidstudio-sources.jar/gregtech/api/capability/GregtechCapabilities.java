package gregtech.api.capability;

import gregtech.api.GTValues;
import gregtech.api.capability.impl.EUToFEProvider;
import gregtech.api.items.toolitem.ItemGTToolbelt;
import gregtech.api.util.GTUtility;
import gregtech.common.metatileentities.converter.ConverterTrait;

import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityInject;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod.EventBusSubscriber(modid = GTValues.MODID)
public class GregtechCapabilities {

    @CapabilityInject(IEnergyContainer.class)
    public static Capability<IEnergyContainer> CAPABILITY_ENERGY_CONTAINER = null;

    @CapabilityInject(IElectricItem.class)
    public static Capability<IElectricItem> CAPABILITY_ELECTRIC_ITEM = null;

    @CapabilityInject(ItemGTToolbelt.ToolStackHandler.class)
    public static Capability<ItemGTToolbelt.ToolStackHandler> CAPABILITY_TOOLBELT_HANDLER = null;

    @CapabilityInject(IMultiblockController.class)
    public static Capability<IMultiblockController> CAPABILITY_MULTIBLOCK_CONTROLLER = null;

    @CapabilityInject(ConverterTrait.class)
    public static Capability<ConverterTrait> CAPABILITY_CONVERTER = null;

    private static final ResourceLocation CAPABILITY_EU_TO_FE = GTUtility.gregtechId("fe_capability");

    @SubscribeEvent
    public static void attachTileCapability(AttachCapabilitiesEvent<TileEntity> event) {
        event.addCapability(CAPABILITY_EU_TO_FE, new EUToFEProvider(event.getObject()));
    }
}
